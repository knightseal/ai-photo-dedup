# 快速执行清单

## ✅ 本地测试

```bash
# 1. 进入项目目录
cd ai-photo-dedup

# 2. 创建虚拟环境
python -m venv venv
source venv/bin/activate  # macOS/Linux
# venv\Scripts\activate   # Windows

# 3. 安装依赖
pip install -r requirements.txt

# 4. 测试扫描（使用测试目录）
mkdir -p test_photos
# 复制几张测试图片到 test_photos/
python photo_dedup.py scan test_photos --output test_report.html

# 5. 查看报告
open test_report.html  # macOS
# start test_report.html  # Windows
```

## ✅ GitHub 推送

```bash
# 1. 初始化仓库
git init

# 2. 添加文件
git add .

# 3. 提交
git commit -m "feat: Initial implementation of AI photo deduplicator

- Perceptual hashing (pHash, dHash, wHash, aHash)
- CLIP semantic analysis for refinement
- HTML report generation with thumbnails
- Safe cleaning with trash/recovery
- Rich CLI interface"

# 4. 连接远程（替换用户名）
git remote add origin https://github.com/YOUR_USERNAME/ai-photo-dedup.git

# 5. 推送
git push -u origin main
```

## ✅ 创建 Release

1. GitHub 仓库页面 → **Releases** → **Create a new release**
2. Tag: `v1.0.0`
3. Title: `AI Photo Deduplicator v1.0.0`
4. Description: 复制 README 的功能列表
5. 点击 **Publish release**

---

## 📁 文件清单

必须包含的文件：
- [ ] photo_dedup.py
- [ ] requirements.txt
- [ ] README.md
- [ ] GUIDE.md
- [ ] core/__init__.py
- [ ] core/scanner.py
- [ ] core/hasher.py
- [ ] core/grouper.py
- [ ] core/ai_analyzer.py
- [ ] core/cleaner.py
- [ ] utils/__init__.py
- [ ] utils/image_utils.py
- [ ] utils/report_generator.py
