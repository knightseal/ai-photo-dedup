#!/usr/bin/env python3
"""
AI Photo Deduplicator - 智能重复照片清理工具
主程序入口
"""

import os
import sys
import json
import click
from pathlib import Path
from typing import Optional, List
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.panel import Panel

from core.scanner import ImageScanner
from core.hasher import ImageHasher
from core.grouper import SimilarityGrouper
from core.ai_analyzer import AIAnalyzer
from core.cleaner import PhotoCleaner
from utils.report_generator import ReportGenerator

console = Console()


@click.group()
@click.version_option(version="1.0.0")
def cli():
    """AI Photo Deduplicator - 智能重复照片清理工具"""
    pass


@cli.command()
@click.argument('path', type=click.Path(exists=True))
@click.option('--output', '-o', default='dedup_report.html', help='输出报告路径')
@click.option('--threshold', '-t', default=10, help='相似度阈值 (汉明距离，越小越严格)')
@click.option('--use-ai', '-a', is_flag=True, help='启用 AI 语义分析')
@click.option('--recursive', '-r', default=True, help='递归扫描子目录')
@click.option('--min-size', default=10240, help='最小文件大小 (字节)')
@click.option('--formats', default='jpg,jpeg,png,heic,webp,bmp,tiff', help='扫描的图片格式')
def scan(path: str, output: str, threshold: int, use_ai: bool, recursive: bool, min_size: int, formats: str):
    """扫描目录中的重复照片"""
    
    target_path = Path(path)
    allowed_formats = tuple(f'.{f.strip().lower()}' for f in formats.split(','))
    
    console.print(Panel.fit(
        f"[bold cyan]🔍 AI Photo Deduplicator[/bold cyan]\n"
        f"目标目录: [green]{target_path.absolute()}[/green]\n"
        f"相似度阈值: [yellow]{threshold}[/yellow] | "
        f"AI 分析: [yellow]{'开启' if use_ai else '关闭'}[/yellow]",
        title="扫描配置"
    ))
    
    # 阶段 1: 扫描文件
    with console.status("[bold green]正在扫描图片文件...") as status:
        scanner = ImageScanner(allowed_formats, min_size)
        image_files = scanner.scan(target_path, recursive)
        console.print(f"✅ 发现 [bold]{len(image_files)}[/bold] 个图片文件")
    
    if len(image_files) < 2:
        console.print("[yellow]⚠️ 图片数量不足，无需检测重复[/yellow]")
        return
    
    # 阶段 2: 计算哈希
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("[cyan]计算图片哈希...", total=len(image_files))
        hasher = ImageHasher()
        hashes = {}
        for img_path in image_files:
            hash_val = hasher.compute_hash(img_path)
            if hash_val:
                hashes[img_path] = hash_val
            progress.advance(task)
    
    console.print(f"✅ 成功计算 [bold]{len(hashes)}[/bold] 个图片哈希")
    
    # 阶段 3: 分组相似图片
    with console.status("[bold green]正在分组相似图片..."):
        grouper = SimilarityGrouper(threshold)
        groups = grouper.group(hashes)
        console.print(f"✅ 发现 [bold]{len(groups)}[/bold] 组相似图片")
    
    # 阶段 4: AI 精筛 (可选)
    if use_ai and groups:
        with console.status("[bold green]AI 正在分析图片语义..."):
            analyzer = AIAnalyzer()
            groups = analyzer.refine_groups(groups)
            console.print(f"✅ AI 精筛完成，剩余 [bold]{len(groups)}[/bold] 组")
    
    # 阶段 5: 生成报告
    with console.status("[bold green]正在生成报告..."):
        report_gen = ReportGenerator()
        stats = report_gen.generate(output, groups, target_path)
        console.print(f"✅ 报告已保存: [bold green]{output}[/bold green]")
    
    # 显示统计
    table = Table(title="扫描结果统计")
    table.add_column("指标", style="cyan")
    table.add_column("数值", style="green")
    table.add_row("扫描图片总数", str(len(image_files)))
    table.add_row("有效哈希数", str(len(hashes)))
    table.add_row("重复组数", str(len(groups)))
    table.add_row("可释放空间", f"{stats.get('potential_space_saved', 0) / 1024 / 1024:.2f} MB")
    console.print(table)
    
    if groups:
        console.print(f"\n[bold yellow]💡 提示: 使用 [cyan]photo_dedup.py preview {output}[/cyan] 查看详情")
        console.print(f"[bold yellow]💡 提示: 使用 [cyan]photo_dedup.py clean {path} --execute[/cyan] 执行清理")


@cli.command()
@click.argument('report_path', type=click.Path(exists=True))
def preview(report_path: str):
    """预览扫描报告"""
    import webbrowser
    abs_path = Path(report_path).absolute()
    console.print(f"🌐 正在打开报告: [green]{abs_path}[/green]")
    webbrowser.open(f'file://{abs_path}')


@cli.command()
@click.argument('path', type=click.Path(exists=True))
@click.option('--execute', is_flag=True, help='实际执行清理（否则仅模拟）')
@click.option('--keep-best', default=True, help='自动保留每组中质量最佳的图片')
@click.option('--trash-dir', default='.photo_dedup_trash', help='重复文件移动目录')
@click.option('--report', '-r', help='使用指定报告进行清理')
def clean(path: str, execute: bool, keep_best: bool, trash_dir: str, report: Optional[str]):
    """清理重复照片"""
    
    target_path = Path(path)
    
    if not execute:
        console.print(Panel.fit(
            "[bold yellow]⚠️ 模拟模式[/bold yellow]\n"
            "当前为模拟运行，不会实际删除任何文件。\n"
            "添加 [cyan]--execute[/cyan] 参数以实际执行清理。",
            title="安全提示"
        ))
    
    cleaner = PhotoCleaner(target_path, trash_dir)
    
    # 加载报告或重新扫描
    if report:
        with open(report, 'r', encoding='utf-8') as f:
            # 从 HTML 中提取 JSON 数据
            content = f.read()
            # 简化处理：重新扫描
    
    # 执行清理
    with console.status("[bold green]正在分析最佳保留项..."):
        plan = cleaner.create_clean_plan(keep_best=keep_best)
    
    if not plan:
        console.print("[green]✅ 未发现重复图片，无需清理[/green]")
        return
    
    # 显示清理计划
    table = Table(title="清理计划")
    table.add_column("保留", style="green")
    table.add_column("删除", style="red")
    table.add_column("节省空间", style="cyan")
    
    total_saved = 0
    for item in plan[:10]:  # 显示前10项
        table.add_row(
            str(item['keep'])[:50] + '...',
            f"{len(item['remove'])} 个文件",
            f"{item['space_saved'] / 1024 / 1024:.2f} MB"
        )
        total_saved += item['space_saved']
    
    if len(plan) > 10:
        table.add_row("...", f"还有 {len(plan) - 10} 组", "...")
    
    console.print(table)
    console.print(f"\n预计释放空间: [bold green]{total_saved / 1024 / 1024:.2f} MB[/bold green]")
    
    if execute:
        confirm = click.confirm("确认执行清理？文件将被移动到回收站目录", default=False)
        if confirm:
            with Progress(console=console) as progress:
                task = progress.add_task("[red]清理中...", total=len(plan))
                for item in plan:
                    cleaner.execute_clean(item)
                    progress.advance(task)
            console.print(f"[green]✅ 清理完成！释放了 {total_saved / 1024 / 1024:.2f} MB 空间[/green]")
            console.print(f"[yellow]📁 被删除文件位于: {trash_dir}[/yellow]")
    else:
        console.print(f"\n[bold]使用 [cyan]--execute[/cyan] 参数执行实际清理[/bold]")


@cli.command()
@click.argument('trash_dir', type=click.Path(exists=True))
def restore(trash_dir: str):
    """从回收站恢复文件"""
    trash_path = Path(trash_dir)
    cleaner = PhotoCleaner(trash_path.parent, trash_dir)
    
    with console.status("[bold green]正在恢复文件..."):
        restored = cleaner.restore_all()
    
    console.print(f"[green]✅ 成功恢复 {restored} 个文件[/green]")


if __name__ == '__main__':
    cli()
