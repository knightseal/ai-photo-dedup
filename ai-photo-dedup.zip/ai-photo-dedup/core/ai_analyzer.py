"""
AI 语义分析模块
使用 CLIP 模型进行图片语义相似度分析
"""

import torch
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple
from PIL import Image
import warnings

warnings.filterwarnings('ignore')


class AIAnalyzer:
    """基于 CLIP 的图片语义分析器"""
    
    def __init__(self, model_name: str = "openai/clip-vit-base-patch32"):
        """
        Args:
            model_name: CLIP 模型名称
        """
        self.model_name = model_name
        self.model = None
        self.processor = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self._load_model()
    
    def _load_model(self):
        """加载 CLIP 模型"""
        try:
            from transformers import CLIPProcessor, CLIPModel
            
            print(f"正在加载 CLIP 模型: {self.model_name}")
            self.model = CLIPModel.from_pretrained(self.model_name).to(self.device)
            self.processor = CLIPProcessor.from_pretrained(self.model_name)
            self.model.eval()
            print(f"✅ CLIP 模型加载完成 (设备: {self.device})")
            
        except ImportError:
            print("⚠️ transformers 未安装，AI 分析功能不可用")
            print("   运行: pip install transformers")
            self.model = None
        except Exception as e:
            print(f"⚠️ CLIP 模型加载失败: {e}")
            self.model = None
    
    def get_image_embedding(self, image_path: Path) -> np.ndarray:
        """
        获取图片的 CLIP 嵌入向量
        
        Returns:
            归一化的嵌入向量
        """
        if self.model is None:
            return None
            
        try:
            image = Image.open(image_path).convert('RGB')
            inputs = self.processor(images=image, return_tensors="pt").to(self.device)
            
            with torch.no_grad():
                image_features = self.model.get_image_features(**inputs)
                # 归一化
                image_features = image_features / image_features.norm(dim=-1, keepdim=True)
                
            return image_features.cpu().numpy().flatten()
            
        except Exception as e:
            print(f"处理图片失败 {image_path}: {e}")
            return None
    
    def compute_semantic_similarity(self, image_path1: Path, image_path2: Path) -> float:
        """
        计算两张图片的语义相似度
        
        Returns:
            0-1 之间的相似度分数
        """
        emb1 = self.get_image_embedding(image_path1)
        emb2 = self.get_image_embedding(image_path2)
        
        if emb1 is None or emb2 is None:
            return 0.0
            
        # 计算余弦相似度
        similarity = np.dot(emb1, emb2)
        return float(similarity)
    
    def refine_groups(self, groups: List[List[Path]], similarity_threshold: float = 0.85) -> List[List[Path]]:
        """
        使用 AI 语义分析精筛相似组
        
        Args:
            groups: 初始分组结果
            similarity_threshold: 语义相似度阈值
            
        Returns:
            精筛后的分组
        """
        if self.model is None:
            print("⚠️ AI 模型未加载，跳过精筛")
            return groups
            
        refined_groups = []
        
        for group in groups:
            if len(group) <= 1:
                continue
                
            # 计算组内所有图片的嵌入向量
            embeddings = {}
            for img_path in group:
                emb = self.get_image_embedding(img_path)
                if emb is not None:
                    embeddings[img_path] = emb
            
            if len(embeddings) < 2:
                continue
                
            # 基于语义相似度重新分组
            semantic_groups = self._cluster_by_semantic(embeddings, similarity_threshold)
            refined_groups.extend(semantic_groups)
            
        return refined_groups
    
    def _cluster_by_semantic(self, embeddings: Dict[Path, np.ndarray], threshold: float) -> List[List[Path]]:
        """基于语义嵌入向量聚类"""
        paths = list(embeddings.keys())
        n = len(paths)
        
        # 构建相似度矩阵
        similarity_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(i, n):
                sim = np.dot(embeddings[paths[i]], embeddings[paths[j]])
                similarity_matrix[i, j] = sim
                similarity_matrix[j, i] = sim
        
        # 简单的贪心聚类
        visited = set()
        groups = []
        
        for i in range(n):
            if i in visited:
                continue
                
            group = [paths[i]]
            visited.add(i)
            
            for j in range(i + 1, n):
                if j not in visited and similarity_matrix[i, j] >= threshold:
                    group.append(paths[j])
                    visited.add(j)
            
            if len(group) > 1:
                groups.append(group)
                
        return groups
    
    def describe_image(self, image_path: Path) -> str:
        """
        生成图片描述（用于报告）
        
        Returns:
            图片内容描述
        """
        if self.model is None:
            return "AI 分析不可用"
            
        # 预定义的常见场景标签
        candidate_labels = [
            "a photo of people", "a landscape photo", "a photo of food",
            "a photo of animals", "a photo of buildings", "a photo of vehicles",
            "a screenshot", "a document", "a meme or funny image",
            "a selfie", "a group photo", "a pet photo"
        ]
        
        try:
            image = Image.open(image_path).convert('RGB')
            inputs = self.processor(
                text=candidate_labels,
                images=image,
                return_tensors="pt",
                padding=True
            ).to(self.device)
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits_per_image = outputs.logits_per_image
                probs = logits_per_image.softmax(dim=1)
                
            # 获取最可能的标签
            best_idx = probs.argmax().item()
            confidence = probs[0, best_idx].item()
            
            return f"{candidate_labels[best_idx]} (置信度: {confidence:.2%})"
            
        except Exception as e:
            return f"分析失败: {e}"
