"""
相似图片分组模块
基于哈希值聚类相似图片
"""

from pathlib import Path
from typing import List, Dict, Tuple
from collections import defaultdict
import numpy as np
from core.hasher import ImageHasher


class SimilarityGrouper:
    """基于哈希相似度的图片分组器"""
    
    def __init__(self, threshold: int = 10, hash_weight: Dict[str, float] = None):
        """
        Args:
            threshold: 汉明距离阈值，小于此值视为相似
            hash_weight: 各种哈希的权重
        """
        self.threshold = threshold
        self.hash_weight = hash_weight or {
            'phash': 0.4,
            'dhash': 0.3,
            'whash': 0.2,
            'ahash': 0.1
        }
        
    def compute_similarity_score(self, hash1: Dict, hash2: Dict) -> float:
        """
        计算两组哈希的加权相似度分数
        
        Returns:
            0-1 之间的相似度分数，1 表示完全相同
        """
        total_score = 0
        total_weight = 0
        
        for hash_type, weight in self.hash_weight.items():
            if hash_type in hash1 and hash_type in hash2:
                distance = ImageHasher.hamming_distance(hash1[hash_type], hash2[hash_type])
                # 将距离转换为相似度分数
                max_distance = len(hash1[hash_type]) ** 2  # 最大可能距离
                similarity = max(0, 1 - (distance / max_distance))
                total_score += similarity * weight
                total_weight += weight
        
        return total_score / total_weight if total_weight > 0 else 0
    
    def group(self, hashes: Dict[Path, Dict]) -> List[List[Path]]:
        """
        将图片分组为相似组
        
        Args:
            hashes: 路径到哈希字典的映射
            
        Returns:
            相似图片组列表，每组包含相似图片的路径
        """
        paths = list(hashes.keys())
        n = len(paths)
        
        # 构建相似度矩阵
        similar_pairs = []
        
        for i in range(n):
            for j in range(i + 1, n):
                score = self.compute_similarity_score(hashes[paths[i]], hashes[paths[j]])
                # 转换为等效汉明距离
                if score > 0.9:  # 高相似度
                    similar_pairs.append((paths[i], paths[j], score))
        
        # 使用并查集进行分组
        groups = self._union_find_grouping(paths, similar_pairs)
        
        # 过滤单张图片的组
        return [g for g in groups if len(g) > 1]
    
    def _union_find_grouping(self, paths: List[Path], similar_pairs: List[Tuple]) -> List[List[Path]]:
        """使用并查集算法分组"""
        parent = {p: p for p in paths}
        
        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]
        
        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py
        
        # 合并相似图片
        for p1, p2, _ in similar_pairs:
            union(p1, p2)
        
        # 收集分组结果
        groups = defaultdict(list)
        for p in paths:
            groups[find(p)].append(p)
        
        return list(groups.values())
    
    def group_by_exact_hash(self, hashes: Dict[Path, Dict]) -> List[List[Path]]:
        """基于精确哈希值分组（用于找出完全相同的图片）"""
        hash_groups = defaultdict(list)
        
        for path, hash_dict in hashes.items():
            # 使用 phash 作为精确匹配键
            if 'phash' in hash_dict:
                hash_str = str(hash_dict['phash'])
                hash_groups[hash_str].append(path)
        
        return [group for group in hash_groups.values() if len(group) > 1]
    
    def find_near_duplicates(self, hashes: Dict[Path, Dict], threshold: int = 5) -> List[List[Path]]:
        """
        查找近似重复图片（更严格的阈值）
        
        Args:
            hashes: 哈希字典
            threshold: 严格的汉明距离阈值
        """
        original_threshold = self.threshold
        self.threshold = threshold
        groups = self.group(hashes)
        self.threshold = original_threshold
        return groups
