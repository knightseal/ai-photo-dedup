"""
图片哈希计算模块
使用感知哈希算法 (pHash, dHash, wHash)
"""

import cv2
import numpy as np
from pathlib import Path
from typing import Optional, Dict
import imagehash
from PIL import Image
import logging

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)


class ImageHasher:
    """图片感知哈希计算器"""
    
    def __init__(self, hash_size: int = 16):
        """
        Args:
            hash_size: 哈希大小，越大越精确但计算量越大
        """
        self.hash_size = hash_size
        
    def compute_hash(self, image_path: Path) -> Optional[Dict[str, imagehash.ImageHash]]:
        """
        计算图片的多种感知哈希
        
        Returns:
            包含多种哈希值的字典，或 None（如果处理失败）
        """
        try:
            # 使用 PIL 打开图片
            with Image.open(image_path) as img:
                # 转换为 RGB（处理各种模式）
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                hashes = {
                    'phash': imagehash.phash(img, hash_size=self.hash_size),
                    'dhash': imagehash.dhash(img, hash_size=self.hash_size),
                    'whash': imagehash.whash(img, hash_size=self.hash_size),
                    'ahash': imagehash.average_hash(img, hash_size=self.hash_size)
                }
                return hashes
                
        except Exception as e:
            logger.warning(f"无法处理图片 {image_path}: {e}")
            return None
    
    def compute_hash_opencv(self, image_path: Path) -> Optional[np.ndarray]:
        """
        使用 OpenCV 计算 pHash（备用方法）
        
        Returns:
            64位哈希值的 numpy 数组
        """
        try:
            # 读取图片并转为灰度
            img = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
            if img is None:
                return None
                
            # 缩放为 32x32
            img = cv2.resize(img, (32, 32))
            
            # DCT 变换
            dct = cv2.dct(np.float32(img))
            
            # 取低频部分 (8x8)
            dct_low = dct[:8, :8]
            
            # 计算平均值（排除直流分量）
            avg = (dct_low.sum() - dct_low[0, 0]) / 63
            
            # 生成哈希
            hash_bits = (dct_low > avg).flatten().astype(int)
            return hash_bits
            
        except Exception as e:
            logger.warning(f"OpenCV 哈希计算失败 {image_path}: {e}")
            return None
    
    @staticmethod
    def hamming_distance(hash1: imagehash.ImageHash, hash2: imagehash.ImageHash) -> int:
        """计算两个哈希值的汉明距离"""
        return hash1 - hash2
    
    @staticmethod
    def hamming_distance_numpy(hash1: np.ndarray, hash2: np.ndarray) -> int:
        """计算 numpy 数组的汉明距离"""
        return np.sum(hash1 != hash2)
    
    def compute_file_hash(self, image_path: Path) -> Optional[str]:
        """计算文件的 MD5 哈希（用于精确重复检测）"""
        import hashlib
        try:
            with open(image_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception:
            return None
