"""
清理执行器
安全地移动或删除重复图片
"""

import os
import shutil
import json
from pathlib import Path
from typing import List, Dict, Tuple
from datetime import datetime
from send2trash import send2trash
from PIL import Image


class PhotoCleaner:
    """照片清理执行器"""
    
    def __init__(self, root_path: Path, trash_dir: str = ".photo_dedup_trash"):
        """
        Args:
            root_path: 根目录路径
            trash_dir: 重复文件存放目录名
        """
        self.root_path = root_path
        self.trash_dir = root_path / trash_dir
        self.manifest_path = self.trash_dir / "manifest.json"
        
    def create_clean_plan(self, groups: List[List[Path]] = None, keep_best: bool = True) -> List[Dict]:
        """
        创建清理计划
        
        Args:
            groups: 相似图片组
            keep_best: 是否自动选择最佳图片保留
            
        Returns:
            清理计划列表
        """
        if groups is None:
            # 如果没有提供组，需要重新扫描
            return []
            
        plan = []
        
        for group in groups:
            if len(group) < 2:
                continue
                
            # 评估每组图片的质量
            scored_images = []
            for img_path in group:
                score = self._evaluate_image_quality(img_path)
                scored_images.append((img_path, score))
            
            # 按分数排序
            scored_images.sort(key=lambda x: x[1], reverse=True)
            
            # 保留最佳，其余删除
            keep_path = scored_images[0][0]
            remove_paths = [p for p, _ in scored_images[1:]]
            
            # 计算可节省空间
            space_saved = sum(p.stat().st_size for p in remove_paths if p.exists())
            
            plan.append({
                'keep': keep_path,
                'remove': remove_paths,
                'space_saved': space_saved,
                'group_size': len(group)
            })
            
        # 按节省空间排序
        plan.sort(key=lambda x: x['space_saved'], reverse=True)
        return plan
    
    def _evaluate_image_quality(self, image_path: Path) -> float:
        """
        评估图片质量分数
        
        考虑因素：
        - 分辨率
        - 文件大小（通常高质量图片更大）
        - EXIF 信息完整性
        - 文件修改时间（较新的可能更好）
        
        Returns:
            质量分数（越高越好）
        """
        score = 0.0
        
        try:
            # 文件大小分数 (0-30)
            size = image_path.stat().st_size
            score += min(30, size / 100000)  # 每 100KB 得 1 分，最高 30
            
            # 分辨率分数 (0-40)
            with Image.open(image_path) as img:
                width, height = img.size
                resolution = width * height
                score += min(40, resolution / 1000000 * 2)  # 每百万像素得 2 分
                
                # 色彩模式加分
                if img.mode in ('RGB', 'RGBA'):
                    score += 5
                    
            # EXIF 信息加分 (0-20)
            try:
                from PIL.ExifTags import TAGS
                exif = img._getexif()
                if exif:
                    score += min(20, len(exif))
            except:
                pass
                
            # 文件路径偏好 (0-10)
            # 优先保留不在 "copy"、"backup" 等目录中的文件
            path_str = str(image_path).lower()
            if any(x in path_str for x in ['copy', 'backup', '复制', '备份']):
                score -= 10
            else:
                score += 10
                
        except Exception:
            # 无法读取的图片给低分
            score = 0
            
        return max(0, score)
    
    def execute_clean(self, plan_item: Dict, move_to_trash: bool = True) -> bool:
        """
        执行清理操作
        
        Args:
            plan_item: 清理计划项
            move_to_trash: 是否移动到回收站（而非永久删除）
            
        Returns:
            是否成功
        """
        removed_files = []
        
        try:
            # 确保回收站目录存在
            self.trash_dir.mkdir(parents=True, exist_ok=True)
            
            for file_path in plan_item['remove']:
                if not file_path.exists():
                    continue
                    
                if move_to_trash:
                    # 保持目录结构移动到回收站
                    relative_path = file_path.relative_to(self.root_path)
                    trash_target = self.trash_dir / relative_path
                    trash_target.parent.mkdir(parents=True, exist_ok=True)
                    
                    shutil.move(str(file_path), str(trash_target))
                    removed_files.append({
                        'original': str(file_path),
                        'trash_location': str(trash_target),
                        'timestamp': datetime.now().isoformat()
                    })
                else:
                    # 永久删除
                    send2trash(str(file_path))
                    removed_files.append({
                        'original': str(file_path),
                        'deleted': True,
                        'timestamp': datetime.now().isoformat()
                    })
            
            # 更新清单文件
            self._update_manifest(plan_item['keep'], removed_files)
            
            return True
            
        except Exception as e:
            print(f"清理失败: {e}")
            return False
    
    def _update_manifest(self, kept_file: Path, removed_files: List[Dict]):
        """更新清理清单"""
        manifest = []
        
        if self.manifest_path.exists():
            try:
                with open(self.manifest_path, 'r', encoding='utf-8') as f:
                    manifest = json.load(f)
            except:
                pass
        
        manifest.append({
            'timestamp': datetime.now().isoformat(),
            'kept': str(kept_file),
            'removed': removed_files
        })
        
        with open(self.manifest_path, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
    
    def restore_all(self) -> int:
        """
        从回收站恢复所有文件
        
        Returns:
            恢复的文件数量
        """
        if not self.manifest_path.exists():
            return 0
            
        with open(self.manifest_path, 'r', encoding='utf-8') as f:
            manifest = json.load(f)
        
        restored_count = 0
        
        for entry in manifest:
            for removed in entry.get('removed', []):
                trash_location = Path(removed['trash_location'])
                original = Path(removed['original'])
                
                if trash_location.exists():
                    original.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(trash_location), str(original))
                    restored_count += 1
        
        # 清空清单
        self.manifest_path.write_text('[]')
        
        return restored_count
    
    def empty_trash(self) -> int:
        """清空回收站（永久删除）"""
        if not self.trash_dir.exists():
            return 0
            
        count = 0
        for item in self.trash_dir.rglob('*'):
            if item.is_file():
                item.unlink()
                count += 1
            
        # 删除空目录
        shutil.rmtree(self.trash_dir, ignore_errors=True)
        
        return count
