"""
图片文件扫描器
"""

import os
from pathlib import Path
from typing import List, Tuple, Set
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm


class ImageScanner:
    """递归扫描目录中的图片文件"""
    
    def __init__(self, allowed_formats: Tuple[str, ...] = None, min_size: int = 10240):
        """
        Args:
            allowed_formats: 允许的图片格式元组，如 ('.jpg', '.png')
            min_size: 最小文件大小（字节），过滤缩略图等
        """
        self.allowed_formats = allowed_formats or ('.jpg', '.jpeg', '.png', '.bmp', '.gif')
        self.min_size = min_size
        
    def scan(self, root_path: Path, recursive: bool = True) -> List[Path]:
        """
        扫描目录中的图片文件
        
        Args:
            root_path: 根目录路径
            recursive: 是否递归扫描子目录
            
        Returns:
            图片文件路径列表
        """
        image_files = []
        
        if recursive:
            pattern = "**/*"
        else:
            pattern = "*"
            
        for file_path in root_path.glob(pattern):
            if file_path.is_file():
                # 检查文件扩展名
                if file_path.suffix.lower() in self.allowed_formats:
                    # 检查文件大小
                    try:
                        if file_path.stat().st_size >= self.min_size:
                            image_files.append(file_path)
                    except (OSError, IOError):
                        continue
                        
        return sorted(image_files)
    
    def scan_parallel(self, root_path: Path, recursive: bool = True, max_workers: int = 8) -> List[Path]:
        """并行扫描（用于超大规模目录）"""
        # 先收集所有子目录
        dirs = [root_path]
        if recursive:
            dirs.extend([d for d in root_path.rglob("*") if d.is_dir()])
        
        all_files = []
        
        def scan_dir(directory: Path) -> List[Path]:
            files = []
            try:
                for item in directory.iterdir():
                    if item.is_file() and item.suffix.lower() in self.allowed_formats:
                        if item.stat().st_size >= self.min_size:
                            files.append(item)
            except (OSError, PermissionError):
                pass
            return files
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(scan_dir, d): d for d in dirs}
            for future in tqdm(as_completed(futures), total=len(futures), desc="扫描目录"):
                all_files.extend(future.result())
                
        return sorted(all_files)
    
    def get_image_info(self, image_path: Path) -> dict:
        """获取图片基本信息"""
        try:
            stat = image_path.stat()
            return {
                'path': str(image_path),
                'name': image_path.name,
                'size': stat.st_size,
                'modified': stat.st_mtime,
                'extension': image_path.suffix.lower()
            }
        except (OSError, IOError):
            return None
