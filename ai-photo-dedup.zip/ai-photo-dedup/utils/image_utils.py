"""
图片处理工具函数
"""

import os
from pathlib import Path
from typing import Tuple, Optional
from PIL import Image, ExifTags
import logging

logger = logging.getLogger(__name__)


def get_image_info(image_path: Path) -> dict:
    """获取图片详细信息"""
    try:
        stat = image_path.stat()
        
        info = {
            'path': str(image_path),
            'name': image_path.name,
            'size_bytes': stat.st_size,
            'modified_time': stat.st_mtime,
            'created_time': stat.st_ctime,
            'extension': image_path.suffix.lower(),
            'width': 0,
            'height': 0,
            'mode': '',
            'format': '',
            'exif': {}
        }
        
        with Image.open(image_path) as img:
            info['width'], info['height'] = img.size
            info['mode'] = img.mode
            info['format'] = img.format
            
            # 提取 EXIF
            try:
                exif = img._getexif()
                if exif:
                    for tag_id, value in exif.items():
                        tag = ExifTags.TAGS.get(tag_id, tag_id)
                        info['exif'][tag] = str(value)
            except:
                pass
                
        return info
        
    except Exception as e:
        logger.error(f"获取图片信息失败 {image_path}: {e}")
        return None


def format_file_size(size_bytes: int) -> str:
    """格式化文件大小显示"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


def is_supported_format(file_path: Path, supported_formats: Tuple[str, ...] = None) -> bool:
    """检查文件是否为支持的图片格式"""
    if supported_formats is None:
        supported_formats = ('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff', '.webp', '.heic')
    
    return file_path.suffix.lower() in supported_formats


def create_thumbnail(image_path: Path, output_path: Path, size: Tuple[int, int] = (200, 200)):
    """创建缩略图"""
    try:
        with Image.open(image_path) as img:
            img.thumbnail(size)
            img.convert('RGB').save(output_path, 'JPEG', quality=80)
        return True
    except Exception as e:
        logger.error(f"创建缩略图失败 {image_path}: {e}")
        return False


def get_image_dimensions(image_path: Path) -> Optional[Tuple[int, int]]:
    """快速获取图片尺寸（不加载整个图片）"""
    try:
        with Image.open(image_path) as img:
            return img.size
    except:
        return None


def compare_image_dimensions(img1: Path, img2: Path) -> dict:
    """比较两张图片的尺寸信息"""
    dim1 = get_image_dimensions(img1)
    dim2 = get_image_dimensions(img2)
    
    if not dim1 or not dim2:
        return {'error': '无法获取尺寸'}
    
    area1 = dim1[0] * dim1[1]
    area2 = dim2[0] * dim2[1]
    
    return {
        'img1_dimensions': dim1,
        'img2_dimensions': dim2,
        'img1_area': area1,
        'img2_area': area2,
        'larger': img1 if area1 > area2 else img2,
        'area_ratio': max(area1, area2) / min(area1, area2) if min(area1, area2) > 0 else 0
    }
