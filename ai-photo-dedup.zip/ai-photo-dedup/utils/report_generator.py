"""
HTML 报告生成器
"""

import json
import base64
from pathlib import Path
from typing import List, Dict
from datetime import datetime
from PIL import Image


class ReportGenerator:
    """生成可视化的 HTML 报告"""
    
    def __init__(self):
        self.template = self._get_template()
    
    def generate(self, output_path: str, groups: List[List[Path]], scan_path: Path) -> Dict:
        """
        生成 HTML 报告
        
        Returns:
            统计信息字典
        """
        # 生成缩略图数据
        group_data = []
        total_duplicates = 0
        total_space = 0
        
        for idx, group in enumerate(groups, 1):
            images = []
            group_size = 0
            
            for img_path in group:
                try:
                    thumb = self._create_thumbnail(img_path)
                    size = img_path.stat().st_size
                    group_size += size
                    
                    images.append({
                        'path': str(img_path),
                        'name': img_path.name,
                        'size': self._format_size(size),
                        'thumbnail': thumb,
                        'dimensions': self._get_dimensions(img_path)
                    })
                except Exception:
                    continue
            
            if len(images) > 1:
                group_data.append({
                    'id': idx,
                    'images': images,
                    'count': len(images),
                    'space': self._format_size(group_size)
                })
                total_duplicates += len(images) - 1
                total_space += group_size
        
        # 渲染 HTML
        html_content = self._render_html(group_data, scan_path, {
            'total_groups': len(group_data),
            'total_duplicates': total_duplicates,
            'total_space': self._format_size(total_space)
        })
        
        # 保存
        Path(output_path).write_text(html_content, encoding='utf-8')
        
        return {
            'groups_found': len(group_data),
            'duplicate_count': total_duplicates,
            'potential_space_saved': total_space
        }
    
    def _create_thumbnail(self, image_path: Path, max_size: int = 200) -> str:
        """创建 base64 编码的缩略图"""
        try:
            with Image.open(image_path) as img:
                img.thumbnail((max_size, max_size))
                
                import io
                buffer = io.BytesIO()
                img.convert('RGB').save(buffer, format='JPEG', quality=70)
                img_str = base64.b64encode(buffer.getvalue()).decode()
                return f"data:image/jpeg;base64,{img_str}"
        except Exception:
            return ""
    
    def _get_dimensions(self, image_path: Path) -> str:
        """获取图片尺寸"""
        try:
            with Image.open(image_path) as img:
                return f"{img.size[0]}x{img.size[1]}"
        except:
            return "未知"
    
    def _format_size(self, size_bytes: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} TB"
    
    def _render_html(self, groups: List[Dict], scan_path: Path, stats: Dict) -> str:
        """渲染 HTML 内容"""
        
        groups_html = ""
        for group in groups:
            images_html = ""
            for img in group['images']:
                images_html += f'''
                <div class="image-card">
                    <img src="{img['thumbnail']}" alt="{img['name']}">
                    <div class="image-info">
                        <div class="image-name" title="{img['path']}">{img['name']}</div>
                        <div class="image-meta">{img['dimensions']} | {img['size']}</div>
                    </div>
                </div>
                '''
            
            groups_html += f'''
            <div class="group">
                <div class="group-header">
                    <span class="group-id">#{group['id']}</span>
                    <span class="group-count">{group['count']} 张相似图片</span>
                    <span class="group-space">总大小: {group['space']}</span>
                </div>
                <div class="group-images">
                    {images_html}
                </div>
            </div>
            '''
        
        return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Photo Deduplicator - 扫描报告</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        .header {{
            background: white;
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }}
        .header h1 {{
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }}
        .header .subtitle {{
            color: #666;
            font-size: 14px;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }}
        .stat-card {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
        }}
        .stat-value {{
            font-size: 32px;
            font-weight: bold;
        }}
        .stat-label {{
            font-size: 14px;
            opacity: 0.9;
            margin-top: 5px;
        }}
        .group {{
            background: white;
            border-radius: 16px;
            margin-bottom: 20px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }}
        .group-header {{
            background: #f8f9fa;
            padding: 15px 20px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            align-items: center;
            gap: 15px;
        }}
        .group-id {{
            background: #667eea;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
        }}
        .group-count {{
            color: #666;
            font-size: 14px;
        }}
        .group-space {{
            margin-left: auto;
            color: #28a745;
            font-weight: 500;
        }}
        .group-images {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            padding: 20px;
        }}
        .image-card {{
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }}
        .image-card:hover {{
            border-color: #667eea;
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }}
        .image-card img {{
            width: 100%;
            height: 150px;
            object-fit: cover;
        }}
        .image-info {{
            padding: 12px;
        }}
        .image-name {{
            font-size: 13px;
            color: #333;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 4px;
        }}
        .image-meta {{
            font-size: 12px;
            color: #888;
        }}
        .empty-state {{
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }}
        .empty-state h2 {{
            color: #333;
            margin-bottom: 10px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 AI Photo Deduplicator 扫描报告</h1>
            <div class="subtitle">扫描目录: {scan_path} | 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-value">{stats['total_groups']}</div>
                    <div class="stat-label">重复组</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{stats['total_duplicates']}</div>
                    <div class="stat-label">重复图片数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{stats['total_space']}</div>
                    <div class="stat-label">可释放空间</div>
                </div>
            </div>
        </div>
        
        {groups_html if groups else '<div class="empty-state"><h2>🎉 未发现重复图片</h2><p>你的照片库很整洁！</p></div>'}
    </div>
</body>
</html>'''
    
    def _get_template(self) -> str:
        """获取 HTML 模板"""
        return ""  # 模板已内联在 _render_html 中
