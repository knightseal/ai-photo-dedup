# AI Photo Deduplicator - 完整操作指南

## 📋 项目简介

这是一个基于 **感知哈希 + AI 语义分析** 的智能重复照片清理工具，可以：
- 🔍 检测视觉上相似的重复/近似重复照片
- 🤖 使用 CLIP 模型进行语义验证
- 📊 生成可视化 HTML 报告
- 🛡️ 安全清理（移动到回收站，可恢复）

---

## 🚀 快速开始

### 1. 克隆/下载项目

```bash
# 创建项目目录
mkdir ai-photo-dedup
cd ai-photo-dedup

# 复制以下文件到该目录：
# - photo_dedup.py (主程序)
# - requirements.txt
# - core/ (目录及所有文件)
# - utils/ (目录及所有文件)
# - README.md
```

### 2. 安装依赖

```bash
# 创建虚拟环境（推荐）
python -m venv venv

# 激活虚拟环境
# macOS/Linux:
source venv/bin/activate
# Windows:
venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt
```

### 3. 基本使用

```bash
# 扫描目录（模拟模式，不实际删除）
python photo_dedup.py scan ~/Pictures --output report.html

# 查看生成的报告
python photo_dedup.py preview report.html

# 执行清理（会实际移动重复文件到回收站）
python photo_dedup.py clean ~/Pictures --execute
```

---

## 📁 项目结构

```
ai-photo-dedup/
├── photo_dedup.py          # 主程序入口 (CLI)
├── requirements.txt        # Python 依赖
├── README.md              # 项目说明
├── core/                  # 核心模块
│   ├── __init__.py
│   ├── scanner.py         # 图片扫描器
│   ├── hasher.py          # 感知哈希计算
│   ├── grouper.py         # 相似图片分组
│   ├── ai_analyzer.py     # CLIP AI 分析
│   └── cleaner.py         # 清理执行器
├── utils/                 # 工具模块
│   ├── __init__.py
│   ├── image_utils.py     # 图片处理工具
│   └── report_generator.py # HTML 报告生成
└── tests/                 # 测试目录
    └── __init__.py
```

---

## 🛠️ 详细命令说明

### scan - 扫描重复图片

```bash
python photo_dedup.py scan [OPTIONS] PATH

选项：
  --output, -o     输出报告路径 (默认: dedup_report.html)
  --threshold, -t  相似度阈值，越小越严格 (默认: 10)
  --use-ai, -a     启用 AI 语义分析 (较慢但更准)
  --recursive, -r  递归扫描子目录 (默认: True)
  --min-size       最小文件大小，过滤缩略图 (默认: 10240)
  --formats        扫描的图片格式 (默认: jpg,jpeg,png,heic,webp,bmp,tiff)

示例：
# 基础扫描
python photo_dedup.py scan ~/Pictures

# 启用 AI 分析（更精确但更慢）
python photo_dedup.py scan ~/Pictures --use-ai --threshold 8

# 扫描特定格式
python photo_dedup.py scan ~/Photos --formats jpg,png,raw
```

### preview - 预览报告

```bash
python photo_dedup.py preview REPORT_PATH

示例：
python photo_dedup.py preview dedup_report.html
```

### clean - 清理重复图片

```bash
python photo_dedup.py clean [OPTIONS] PATH

选项：
  --execute        实际执行清理（否则仅模拟）
  --keep-best      自动保留每组中质量最佳的 (默认: True)
  --trash-dir      重复文件移动目录 (默认: .photo_dedup_trash)
  --report, -r     使用指定报告进行清理

示例：
# 模拟运行（查看会删除哪些文件）
python photo_dedup.py clean ~/Pictures

# 实际执行清理
python photo_dedup.py clean ~/Pictures --execute

# 使用特定报告清理
python photo_dedup.py clean ~/Pictures --report report.html --execute
```

### restore - 恢复已删除文件

```bash
python photo_dedup.py restore TRASH_DIR

示例：
python photo_dedup.py restore ~/Pictures/.photo_dedup_trash
```

---

## 🔬 工作原理

### 1. 感知哈希算法

工具使用多种感知哈希算法检测相似图片：

- **pHash (感知哈希)**：基于 DCT 变换，对亮度变化鲁棒
- **dHash (差异哈希)**：基于梯度变化，对小幅裁剪/缩放鲁棒  
- **wHash (小波哈希)**：基于小波变换，精度更高
- **aHash (平均哈希)**：最简单快速

### 2. AI 语义分析 (可选)

使用 OpenAI CLIP 模型：
- 提取图片语义嵌入向量
- 计算语义相似度
- 过滤掉 "看起来相似但内容不同" 的图片

### 3. 质量评估

自动选择保留哪张图片的标准：
- 分辨率（越高越好）
- 文件大小（通常高质量更大）
- EXIF 信息完整性
- 文件路径（优先保留非 "copy/backup" 目录中的）

---

## 📊 报告解读

生成的 HTML 报告包含：

1. **统计概览**：
   - 重复组数量
   - 重复图片总数
   - 可释放空间

2. **分组详情**：
   - 每组显示所有相似图片缩略图
   - 显示文件名、尺寸、大小
   - 按组编号组织

3. **操作按钮**：
   - 点击缩略图可查看原图
   - 报告可直接在浏览器打开

---

## ⚙️ 高级配置

### 调整相似度阈值

```python
# 更严格（只找非常相似的）
--threshold 5

# 较宽松（找出更多可能的重复）
--threshold 15
```

### 自定义质量评估权重

编辑 `core/cleaner.py` 中的 `_evaluate_image_quality` 方法：

```python
# 当前权重：
# - 文件大小: 30 分
# - 分辨率: 40 分
# - EXIF: 20 分
# - 路径: 10 分
```

### 使用不同的 CLIP 模型

编辑 `core/ai_analyzer.py`：

```python
# 更快但精度较低
model_name = "openai/clip-vit-base-patch32"

# 更慢但精度更高
model_name = "openai/clip-vit-large-patch14"
```

---

## 🧪 测试

```bash
# 创建测试图片集
mkdir test_photos
cp some_photo.jpg test_photos/
cp some_photo.jpg test_photos/photo_copy.jpg

# 运行扫描
python photo_dedup.py scan test_photos

# 应该能检测出这两张是重复的
```

---

## ⚠️ 注意事项

1. **首次运行**：AI 模型会自动下载（约 500MB），需要网络连接
2. **处理时间**：取决于图片数量和是否启用 AI
   - 1000 张图片：约 1-2 分钟（无 AI）
   - 1000 张图片：约 5-10 分钟（启用 AI）
3. **安全机制**：
   - 默认模拟模式，不会删除任何文件
   - 实际清理时会移动到 `.photo_dedup_trash` 目录
   - 可随时使用 `restore` 命令恢复

---

## 🐛 故障排除

### 问题：无法导入 PIL
```bash
pip install Pillow
```

### 问题：CLIP 模型下载失败
```bash
# 手动设置 HuggingFace 镜像
export HF_ENDPOINT=https://hf-mirror.com
python photo_dedup.py scan ~/Pictures --use-ai
```

### 问题：处理 HEIC/RAW 格式失败
```bash
pip install pillow-heif rawpy
```

### 问题：内存不足
```bash
# 减少并行线程（修改 core/scanner.py 中的 max_workers）
# 或分批处理子目录
```

---

## 📄 License

MIT License - 自由使用和修改

---

## 🙏 致谢

- [imagehash](https://github.com/JohannesBuchner/imagehash) - 感知哈希库
- [CLIP](https://github.com/openai/CLIP) - OpenAI 视觉模型
- [Rich](https://github.com/Textualize/rich) - 终端美化
